﻿using System;
using System.Collections.Generic;

namespace _1Milestone.Models;

public partial class Borrow
{
    public int BorrowId { get; set; }

    public int StudentId { get; set; }

    public int BookId { get; set; }

    public DateTime? TakenDate { get; set; }

    public DateTime? ReturnDate { get; set; }
}
