﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace _1Milestone.Models;

public partial class Milestone1Context : DbContext
{
    public Milestone1Context()
    {
    }

    public Milestone1Context(DbContextOptions<Milestone1Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Book> Books { get; set; }

    public virtual DbSet<Borrow> Borrows { get; set; }

    public virtual DbSet<StudentsDel> StudentsDels { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//        => optionsBuilder.UseSqlServer("Data Source=IN3245920W2;Initial Catalog=Milestone1;Trusted_Connection=True;TrustServerCertificate=True;database=Milestone1");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Book>(entity =>
        {
            entity.ToTable("books");

            entity.Property(e => e.BookId)
                .ValueGeneratedNever()
                .HasColumnName("bookId");
            entity.Property(e => e.AuthorId).HasColumnName("authorId");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.PageCount).HasColumnName("pageCount");
        });

        modelBuilder.Entity<Borrow>(entity =>
        {
            entity.ToTable("Borrow");

            entity.Property(e => e.BorrowId).HasColumnName("borrowId");
            entity.Property(e => e.BookId).HasColumnName("bookId");
            entity.Property(e => e.ReturnDate)
                .HasColumnType("date")
                .HasColumnName("returnDate");
            entity.Property(e => e.StudentId).HasColumnName("studentId");
            entity.Property(e => e.TakenDate)
                .HasColumnType("date")
                .HasColumnName("takenDate");
        });

        modelBuilder.Entity<StudentsDel>(entity =>
        {
            entity.HasKey(e => e.StudentId);

            entity.ToTable("studentsDel");

            entity.Property(e => e.StudentId).HasColumnName("studentId");
            entity.Property(e => e.Class).HasColumnName("class");
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("gender");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
