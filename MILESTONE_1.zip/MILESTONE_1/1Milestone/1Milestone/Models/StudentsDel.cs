﻿using System;
using System.Collections.Generic;

namespace _1Milestone.Models;

public partial class StudentsDel
{
    public int StudentId { get; set; }

    public string? Name { get; set; }

    public string? Gender { get; set; }

    public int? Class { get; set; }
}
