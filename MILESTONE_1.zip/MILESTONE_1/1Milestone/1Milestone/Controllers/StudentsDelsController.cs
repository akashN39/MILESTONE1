﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using _1Milestone.Models;

namespace _1Milestone.Controllers
{
    public class StudentsDelsController : Controller
    {
        private readonly Milestone1Context _context;

        public StudentsDelsController(Milestone1Context context)
        {
            _context = context;
        }

        // GET: StudentsDels
        public async Task<IActionResult> Index()
        {
              return View(await _context.StudentsDels.ToListAsync());
        }

        // GET: StudentsDels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.StudentsDels == null)
            {
                return NotFound();
            }

            var studentsDel = await _context.StudentsDels
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (studentsDel == null)
            {
                return NotFound();
            }

            return View(studentsDel);
        }

        // GET: StudentsDels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: StudentsDels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StudentId,Name,Gender,Class")] StudentsDel studentsDel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(studentsDel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(studentsDel);
        }

        // GET: StudentsDels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.StudentsDels == null)
            {
                return NotFound();
            }

            var studentsDel = await _context.StudentsDels.FindAsync(id);
            if (studentsDel == null)
            {
                return NotFound();
            }
            return View(studentsDel);
        }

        // POST: StudentsDels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StudentId,Name,Gender,Class")] StudentsDel studentsDel)
        {
            if (id != studentsDel.StudentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(studentsDel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentsDelExists(studentsDel.StudentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(studentsDel);
        }

        // GET: StudentsDels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.StudentsDels == null)
            {
                return NotFound();
            }

            var studentsDel = await _context.StudentsDels
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (studentsDel == null)
            {
                return NotFound();
            }

            return View(studentsDel);
        }

        // POST: StudentsDels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.StudentsDels == null)
            {
                return Problem("Entity set 'Milestone1Context.StudentsDels'  is null.");
            }
            var studentsDel = await _context.StudentsDels.FindAsync(id);
            if (studentsDel != null)
            {
                _context.StudentsDels.Remove(studentsDel);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentsDelExists(int id)
        {
          return _context.StudentsDels.Any(e => e.StudentId == id);
        }
    }
}
